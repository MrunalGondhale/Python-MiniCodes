const express = require("express");
const {
  getCourseById,
  getCourses,
  CreateCourse,
  DeleteCourse,
  UpdateCourse,
} = require("../controllers/courseController.js");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware.js");

router.route("/").get(protect, getCourses);
router
  .route("/:id")
  .get(getCourseById)
  .delete(protect, DeleteCourse)
  .put(protect, UpdateCourse);
router.route("/create").post(protect, CreateCourse);

module.exports =router;