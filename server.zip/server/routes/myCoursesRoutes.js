const express = require('express');
const{ SubscribedCourse }  =require("../controllers/myCoursesController.js");
const{ protect } = require("../middleware/authMiddleware.js");
const router = express.Router();

router.route("/").post(protect, SubscribedCourse);

module.exports= router;


