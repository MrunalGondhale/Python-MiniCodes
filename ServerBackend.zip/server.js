const express = require('express')
const bodyParser = require('body-parser')

const app = express();
const dotenv = require('dotenv')
const userRoutes = require('./routes/userRoutes.js')
const postRoutes = require('./routes/postRoutes.js')
const courseRoutes = require('./routes/courseRoutes')
const MyCourseRoutes = require('./routes/MyCourseRoutes')




const  { errorHandler, notFound } = require('./middleware/errorMiddleware.js');
//const path = require('path')



const connectDB = require('./config/db')

dotenv.config();
connectDB();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));




app.get('/' , (req, res)=>{
    res.send('API is Running')
})

app.use("/api/users", userRoutes);
app.use("/api/posts", postRoutes);
app.use("/api/courses", courseRoutes);
app.use("/api/mycourse", MyCourseRoutes);


// const courseRouter = require('./routes/courses')
// app.use('/courses', courseRouter)



// const __dirname = path.resolve();

if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "/frontend/build")));

  app.get("*", (req, res) =>
    res.sendFile(path.resolve(__dirname, "frontend", "build", "index.html"))
  );
} else {
  app.get("/", (req, res) => {
    res.send("API is running..");
  });
}
// --------------------------deployment------------------------------

// Error Handling middlewares
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

app.listen(
    PORT,
    console.log(
      `Server running in ${process.env.NODE_ENV} mode on port ${PORT}`
    )
  );