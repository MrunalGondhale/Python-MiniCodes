const asyncHandler = require('express-async-handler')
const User = require('../models/userModel');
const generateToken  = require('../utils/generateToken');

const registerUser = asyncHandler(async (req, res)=>{
    const {name, email , password , role, pic}= req.body;
   

    const userExists = await User.findOne({email})
     if(userExists)
     {
        res.status(400)
        throw new Error("User already Exists");
     }

     const user = await User.create(
         {
             name,
             email,
             password,
             pic,
             role
         }
     );
     if(user)
     {
         res.status(201).json({
             _id:user._id,
             name:user.name,
             email:user.email,
             role:user.role,
             token: generateToken(user._id),


             pic:user.pic
         });

}
     else{
         res.status(400);
         throw new Error("Errror Occured");
     }

});

const authUser = asyncHandler(async (req, res) => {
    const { email, password } = req.body;
  
    const user = await User.findOne({ email });
  
    if (user && (await user.matchPassword(password))) {
      res.json({
        _id: user._id,
        name: user.name,
        email: user.email,
        role:user.role,
        pic: user.pic,
        token: generateToken(user._id),

      });
    } else {
      res.status(400);
      throw new Error("Invalid Email or Password");
    }
  });

  const getUsers = asyncHandler(async (req, res)=>{


    const users = await User.find()
    
    res.json(users)
});


  const getById = asyncHandler(
    async(req,res)=>{
        const user = await User.findById(req.params.id)

        if(user)
        {
            res.json(user)
        }
        else{
            res.status(400)
        }
    }
);

const updateUser = asyncHandler(
  async(req,res)=>{
    const {name, email , password }= req.body;


      const user = await User.findById(req.params.id)
      

    

      if (User)
      {
          user.name = name
          user.email = email
          user.password = password
      

          const updatedUser = await user.save()
          res.json(updatedUser)
      }else{
          res.status(400)
          throw new Error("Not Found")
      }
  }
)

const delUser = asyncHandler(
  async(req,res)=>{
      const user = await User.findById(req.params.id)

      
     

      if(user)
      {
         await  user.remove()
         res.json({message:"Removed"})
      }
      else{
          res.status(400)
          throw new Error("Not Found")
      }
  }
);





module.exports = {registerUser , authUser , getById, getUsers , updateUser, delUser};