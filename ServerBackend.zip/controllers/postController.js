const asyncHandler = require('express-async-handler')
const Post = require('../models/postModel');



const getPosts = asyncHandler(async (req, res)=>{


    const post = await Post.find({user:req.user._id})
    res.json(post)
});


const createNotes = asyncHandler(
   async (req,res)=>{
        const {category , title , content } = req.body

        if (!category || !title || !content)
        {
            res.status(400)
            throw new Error("Please Fill all fields")
        }else
        {
            const post = new Post({user:req.user._id, category, title, content})

            const createpost = await post.save()
            res.status(201).json(createpost)
        }

    });


    const getById = asyncHandler(
        async(req,res)=>{
            const post = await Post.findById(req.params.id)

            if(post)
            {
                res.json(post)
            }
            else{
                res.status(400)
            }
        }
    );

    const updateId = asyncHandler(
        async(req,res)=>{
            const{category , title , content} = req.body

            const post = await Post.findById(req.params.id)

            if(post.user.toString()!== req.user.id.toString())
            {
                res.status(404)
                throw new Error("Not fpund")
            }

            if (post)
            {
                post.category = category
                post.title = title
                post.content = content

                const updatedPost = await post.save()
                res.json(updatedPost)
            }else{
                res.status(400)
                throw new Error("Not Found")
            }
        }
    )

    const delById = asyncHandler(
        async(req,res)=>{
            const post = await Post.findById(req.params.id)

            
            if(post.user.toString()!== req.user.id.toString())
            {
                res.status(404)
                throw new Error("Not fpund")
            }

            if(post)
            {
               await  post.remove()
               res.json({message:"Removed"})
            }
            else{
                res.status(400)
                throw new Error("Not Found")
            }
        }
    );

module.exports = {getPosts , createNotes, getById , updateId, delById}