const express = require('express')
const Course = require('../models/courseModel')
const asyncHandler = require('express-async-handler')


const getCourses = asyncHandler(async (req, res)=>{


    const course = await Course.find({user:req.user._id})
    
    res.json(course)
});


const createCourse = asyncHandler(
    async (req,res)=>{
         const {course_ID, name, duration } = req.body
 
         if (!course_ID || !name || !duration)
         {
             res.status(400)
             throw new Error("Please Fill all fields")
         }else
         {
             const course = new Course({user:req.user._id, course_ID,name,duration})
 
             const createcourse = await course.save()
             res.status(201).json(createcourse)
         }
 
     });

     const getByCourse = asyncHandler(
        async(req,res)=>{
            const course = await Course.findById(req.params.id)

            if(course)
            {
                res.json(course)
            }
            else{
                res.status(400)
            }
        }
    );

    const updateCourse = asyncHandler(
        async(req,res)=>{
            const {course_ID, name, duration } = req.body



            const course = await Course.findById(req.params.id)


            if (course)
            {
                course.course_ID = course_ID
                course.name = name
                course.duration=duration

                const updatedCourse = await course.save()
                res.json(updatedCourse)
            }else{
                res.status(400)
                throw new Error("Not Found")
            }
        }
    )

    const delCourse = asyncHandler(
        async(req,res)=>{
            const course = await Course.findById(req.params.id)
      
            
           
      
            if(course)
            {
               await  course.remove()
               res.json({message:"Removed"})
            }
            else{
                res.status(400)
                throw new Error("Not Found")
            }
        }
      );




module.exports = {getCourses, createCourse, getByCourse , delCourse, updateCourse}