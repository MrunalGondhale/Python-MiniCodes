const asyncHandler = require('express-async-handler')
const MyCourse = require('../models/MyCourseModel')
 
 
const SubscribedCourse = asyncHandler(async (req, res) => {
    const {course_Id} = req.body;
  
   
      const myCourse = new MyCourse({ user: req.user._id, course_Id });
  
      const subscribedCourse = await myCourse.save();
  
      res.status(201).json(subscribedCourse);
    
  });

  const getById1 = asyncHandler(
    async(req,res)=>{
        const user = await MyCourse.findById(req.params.id)

        if(user)
        {
            res.json(user)
        }
        else{
            res.status(400)
        }
    }
);
 

const getData = asyncHandler(async (req, res)=>{


  const users = await MyCourse.find()
  
  res.json(users)
});
  module.exports = {SubscribedCourse , getById1 , getData}