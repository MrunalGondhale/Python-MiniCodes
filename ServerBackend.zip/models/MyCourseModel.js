const mongoose = require('mongoose')

 
const CoursesUSchema = mongoose.Schema(
  {
    user: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "user",
      },
    course_Id: {
      type: String,
      required: true,
    },
   
  },
  {
    timestamps: true,
  }
);
 

const MyCourse = mongoose.model('MyCourse', CoursesUSchema)
  module.exports = MyCourse