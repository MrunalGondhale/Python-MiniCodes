const express = require('express');
const {registerUser, authUser, getById, getUsers, updateUser, delUser} = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');



const router = express.Router()

router.route('/').post(registerUser);
router.route('/create').post(registerUser);

router.post("/login", authUser);
router.route('/:id').get(getById);
router.route('/:id').put(protect,updateUser);
router.route('/:id').delete(delUser);



router.route('/').get(getUsers) 



module.exports = router;