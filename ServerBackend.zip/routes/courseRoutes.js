const express = require('express');
const { getCourses, createCourse, getByCourse, updateCourse, delCourse } = require('../controllers/courseController');
const { protect } = require('../middleware/authMiddleware');


const router = express.Router()

router.route('/').get(protect,getCourses);
router.route('/create').post(protect,createCourse)
router.route('/:id').get(getByCourse);
router.route('/:id').put(protect, updateCourse);
router.route('/:id').delete(protect, delCourse);




module.exports = router;