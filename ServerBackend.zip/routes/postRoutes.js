const express = require('express');
const {getPosts, createNotes, getById, updateId, delById} = require('../controllers/postController');
const { protect } = require('../middleware/authMiddleware');



const router = express.Router()

router.route('/').get(protect,getPosts)
router.route('/create').post(protect, createNotes)
router.route('/:id').get(protect,getById) .put(protect, updateId) 
.delete(protect, delById)



module.exports = router;