const express = require('express');
const { SubscribedCourse, getById1, getData } = require('../controllers/MyCourseController');
const { protect } = require('../middleware/authMiddleware');

 
const router = express.Router();
 
router.route("/").post(protect, SubscribedCourse);
router.route('/:id').get(getById1)
router.route('/').get(getData)

 
module.exports = router;
