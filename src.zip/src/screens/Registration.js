import React,{useEffect, useState} from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Form, Container, Button} from "react-bootstrap";
import { useDispatch, useSelector } from 'react-redux'
import { register } from "../actions/userActions";
import ErrorMessage from '../components/ErrorMessage'
import {useHistory , Link} from 'react-router-dom'

function Registration() {

  const [password, setPassword] = useState("");
  const [confirmpassword, setConfirmPassword] = useState("");
  
  const [role, setRole] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pic, setPic]=useState("https://icon-library.com/images/anonymous-avatar-icon/anonymous-avatar-icon-25.jpg");

  const [message, setMessage] = useState(null);
  const [picMessage, setPicMessage] = useState(null);

  
  const dispatch = useDispatch();

  const userRegister = useSelector((state) => state.userRegister);
  const { loading, error, userInfo } = userRegister;

  const history = useHistory();


  //IMAGE

  const postDetails = (pics) => {
    if (
      pics ===
      "https://icon-library.com/images/anonymous-avatar-icon/anonymous-avatar-icon-25.jpg"
    ) {
      return setPicMessage("Please Select an Image");
    }
    setPicMessage(null);
    if (pics.type === "image/jpeg" || pics.type === "image/png") {
      const data = new FormData();
      data.append("file", pics);
      data.append("upload_preset", "notezipper");
      data.append("cloud_name", "piyushproj");
      fetch("https://api.cloudinary.com/v1_1/piyushproj/image/upload", {
        method: "post",
        body: data,
      })
        .then((res) => res.json())
        .then((data) => {
          setPic(data.url.toString());
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      return setPicMessage("Please Select an Image");
    }
  };

  useEffect(() => {
    if (userInfo) {
      history.push("/MyCourses");
    }
  }, [history, userInfo]);







  const submitHandler = (e) => {
    e.preventDefault();
    

    if (password !== confirmpassword) {
      setMessage("Passwords do not match");
    } else dispatch(register(name, email, password,  role, pic ));

  };
  return (
    <div className="LoginForm">
        {error && <ErrorMessage variant="danger">{error}</ErrorMessage>}
        {message && <ErrorMessage variant="danger">{message}</ErrorMessage>}
      <Form onSubmit={submitHandler}>

      <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label className="L1">Name</Form.Label>
          <Form.Control type="text" placeholder="Enter Your Name"
          value={name}
          onChange={(e)=>setName(e.target.value)} />
        </Form.Group>


        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control type="email" placeholder="Enter email" 
          value={email}
          onChange={(e)=>setEmail(e.target.value)}/>
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control type="password" placeholder="Password" 
          value={password}
          onChange={(e)=>setPassword(e.target.value)}/>
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control type="password" placeholder="Confirm Password" 
          value={confirmpassword}
          onChange={(e)=>setConfirmPassword(e.target.value)}/>
        </Form.Group>

        
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Role</Form.Label>
          <Form.Control type="text" placeholder="Your Role" 
          value={role}
          onChange={(e)=>setRole(e.target.value)}/>
        </Form.Group>


        <Form.Group controlId="pic">
            <Form.Label>Profile Picture</Form.Label>
            <Form.File
              onChange={(e) => postDetails(e.target.files[0])}
              
              id="custom-file"
              type="image/png"
              label="Upload Profile Picture"
              custom
            />
          </Form.Group>



      
        <Button variant="primary" type="submit">
          Submit
        </Button> Have an Account ? <Link to="/login">Login</Link>

      </Form>
    </div>
  );
}

export default Registration;
