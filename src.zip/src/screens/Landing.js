import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Button, Container } from 'react-bootstrap';
import { Link } from "react-router-dom";


function Landing() {
    return (
        <div className="container hero-image" >
            
            <div className="hero-text" >
              <Link to="/login"
                                >
                <Button  className="">
                  Login
                </Button>
              </Link>&nbsp;&nbsp;
              <Link to="/register">
                <Button
            
                
                  className=""
                >
                  Signup
                </Button>
              </Link>

              </div>
    
        </div>
    )
}

export default Landing
