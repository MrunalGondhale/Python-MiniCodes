import React, { useEffect } from "react";
import { Accordion, Badge, Button, Table } from "react-bootstrap";
import { Link , withRouter} from "react-router-dom";

import { useDispatch, useSelector } from "react-redux";
import { deleteNoteAction, listNotes} from '../actions/noteActions'


function MyCourses({ history, search }) 
{
  const dispatch = useDispatch();

  const noteList = useSelector((state) => state.noteList);
  const { loading, error, notes } = noteList;
  


  // const filteredNotes = notes.filter((note) =>
  //   note.title.toLowerCase().includes(search.toLowerCase())
  //);

  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  const noteDelete = useSelector((state) => state.noteDelete);
  const {
    loading: loadingDelete,
    error: errorDelete,
    success: successDelete,
  } = noteDelete;

  const noteCreate = useSelector((state) => state.noteCreate);
  const { success: successCreate } = noteCreate;

  const noteUpdate = useSelector((state) => state.noteUpdate);
  const { success: successUpdate } = noteUpdate;

  useEffect(() => {
    dispatch(listNotes());
    if (!userInfo) {
      history.push("/");
    }
  }, [
    dispatch,
    history,
    userInfo,
    successDelete,
    successCreate,
    successUpdate,
  ]);

  const deleteHandler = (id) => {
    if (window.confirm("Are you sure?")) {
      dispatch(deleteNoteAction(id));
    }
  };

  return (
    <div>
    {/* <div style={{"display":"flex" , "justifyContent":"space-around"}}>
    <Link to="/Mentor">
        <Button size="sm">
          Create new Course
        </Button>
      </Link>

      <Link to="/viewUser">
        <Button size="sm">
          View Users
        </Button>
      </Link>
    
      </div> */}


     

    
      {notes && 
        

          notes.map((note) => (
            <div>

            <Table striped bordered hover variant="dark">
            <thead>
              <tr>
  
                <th>Course_Name</th>
                <th>Course_Duration</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <tr key={note._id}>
            
                <td>{note.name}</td>
                <td>{note.duration}</td>
                <td><Button href={`/courses/${note._id}`}>Edit</Button>  <Button
                                variant="danger"
                                className="mx-2"
                                onClick={() => deleteHandler(note._id)}
                              >
                                Delete
                              </Button></td>
                
              </tr>
              
              {/* <tr>
                <td>2</td>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <td>3</td>
                <td colSpan="2">Larry the Bird</td>
                <td>@twitter</td>
                <td><Button href={`/courses/${note._id}`}>Edit</Button>  <Button
                                variant="danger"
                                className="mx-2"
                                onClick={() => deleteHandler(note._id)}
                              >
                                Delete
                              </Button></td>
          
              </tr> */}
            </tbody>
          </Table>
          </div>
            
          
            
                  


                 
          
          ))
           }
   </div>
  );
}

export default withRouter(MyCourses);
