import React, { useEffect, useState } from 'react'
import "bootstrap/dist/css/bootstrap.min.css";
import { Form, Container, Button} from "react-bootstrap";
import { createNoteAction} from '../actions/noteActions';
import {dispatch, useDispatch, useSelector} from 'react-redux'
import { Link, withRouter} from 'react-router-dom';




function Mentor({history}) {

    const dispatch = useDispatch();

    
  const [id, setID] = useState("");
  const [name, setName] = useState("");
  const [duration, setDue] = useState("");




  const noteCreate = useSelector((state) => state.noteCreate);
  const { loading, error, note } = noteCreate;
  console.log(note)

  const resetHandler = () => {
    setID("");
    setName("");
    setDue("");
    
  };



  const submitHandler = (e) => {
    e.preventDefault();
    dispatch(createNoteAction(id, name, duration));
    if (!id|| !name || !duration) return;

    resetHandler();
    history.push("/MyCourses");

  
  };

  useEffect(() => {}, []);

    return (
        <div>
             <Form onSubmit={submitHandler}>

<Form.Group className="mb-3" controlId="formBasicEmail">
    <Form.Label className="L1">Name</Form.Label>
    <Form.Control type="text" placeholder="Course ID"
    value={id}
    onChange={(e)=>setID(e.target.value)} />
  </Form.Group>


  <Form.Group className="mb-3" controlId="formBasicEmail">
    <Form.Label>Name</Form.Label>
    <Form.Control type="text" placeholder="Name" 
    value={name}
    onChange={(e)=>setName(e.target.value)}/>
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicEmail">
    <Form.Label>Duration</Form.Label>
    <Form.Control type="number" placeholder="Duration" 
    value={duration}
    onChange={(e)=>setDue(e.target.value)}/>
  </Form.Group>




  <Button className="mx-2" onClick={resetHandler} variant="danger">
              Reset Feilds
            </Button>


  <Button variant="primary" type="submit">
    Submit
  </Button>

</Form>
        </div>
    )
}

export default Mentor
