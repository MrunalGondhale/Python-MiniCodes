import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link , withRouter} from "react-router-dom";

import { Button, Card, Form } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { deleteNoteAction, updateNoteAction } from '../actions/noteActions';

function SingleNote({ match, history }) {
  const [id, setID] = useState("");
  const [name, setName] = useState("");
  const [duration, setDue] = useState("");

  const dispatch = useDispatch();

  const noteUpdate = useSelector((state) => state.noteUpdate);
  const { loading, error } = noteUpdate;

  const noteDelete = useSelector((state) => state.noteDelete);
  const { loading: loadingDelete, error: errorDelete } = noteDelete;

  const deleteHandler = (id) => {
    if (window.confirm("Are you sure?")) {
      dispatch(deleteNoteAction(id));
    }
    history.push("/MyCourses");
  };

  useEffect(() => {
    const fetching = async () => {
      const { data } = await axios.get(`/api/courses/${match.params.id}`);

      setID(data.id);
      setName(data.name);
      setDue(data.duration);
    
    };

    fetching();
  }, [match.params.id]);

  const resetHandler = () => {
    setID("");
    setName("");
    setDue("");
  };

  const updateHandler = (e) => {
    e.preventDefault();
    dispatch(updateNoteAction(match.params.id, id, name, duration));
    if (!id || !name|| !duration) return;

    resetHandler();
    history.push("/MyCourses");
  };

  return (
    <div>
    <Card>
      <Card.Header>Edit your Note</Card.Header>
      <Card.Body>
        <Form onSubmit={updateHandler}>
         
          <Form.Group controlId="id">
            <Form.Label>ID</Form.Label>
            <Form.Control
              type="text"
              placeholder="Course ID"
              value={id}
              onChange={(e) => setID(e.target.value)}
              
            />
          </Form.Group>

          <Form.Group controlId="name">
            <Form.Label>Name</Form.Label>
            <Form.Control
              type="text"
              placeholder="Name"
            
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </Form.Group>
         
          <Form.Group controlId="duration">
            <Form.Label>Duration</Form.Label>
            <Form.Control
              type="number"
              placeholder="Duration"
              value={duration}
              onChange={(e) => setDue(e.target.value)}
            />
          </Form.Group>
          <Button variant="primary" type="submit">
            Update Note
          </Button>
          <Button
            className="mx-2"
            variant="danger"
            onClick={() => deleteHandler(match.params.id)}
          >
            Delete Note
          </Button>
        </Form>
      </Card.Body>

      <Card.Footer className="text-muted">
      </Card.Footer>
    </Card>
    </div>

  );
}

export default withRouter(SingleNote)
