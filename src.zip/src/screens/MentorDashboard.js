import React from 'react'
import Sidebar from './Slidebar/Sidebar'
import Mentor from './Mentor'
import viewUser from './viewUser'
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { AboutUs} from "./Slidebar/pages/AboutUs";

import './style.css'
import MyCourses from './MyCourses';


function MentorDashboard() {
    return (
         <div style={{"height":"800px" , "background":"grey"}}>
             <Router>
               
      <Sidebar />
      <Switch>
        <Route path="/about-us" exact component={AboutUs} />
        <div style={{"width":"60%" , "margin":"auto" , "paddingLeft":"80px"}}>
        <Route path="/Mentor" exact component={Mentor} />
        <Route path="/MyCourses" exact component={MyCourses} />
        <Route path="/viewUser" exact component={viewUser} />




        </div>

       
      </Switch>
    </Router>

        </div>
    );
}

export default MentorDashboard
