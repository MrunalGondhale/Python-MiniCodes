import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link , withRouter} from "react-router-dom";

import { Button, Card, Form } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { updateUserAction , deleteUserAction } from "../actions/userActions";

function SingleUSer({ match, history }) {
  
    const [password, setPassword] = useState("");
    const [role, setRole] = useState("");
    
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
 

  const dispatch = useDispatch();

  const userUpdate = useSelector((state) => state.userUpdate);
  const { loading, error } = userUpdate;

  const userDelete = useSelector((state) => state.userDelete);
  const { loading: loadingDelete, error: errorDelete } = userDelete;

  const deleteHandler = (id) => {
    if (window.confirm("Are you sure?")) {
      dispatch(deleteUserAction(id));
    }
    history.push("/MyCourses");
  };

  useEffect(() => {
    const fetching = async () => {
      const { data } = await axios.get(`/api/users/${match.params.id}`);

      setName(data.name);
      setEmail(data.email);
      setPassword(data.password);
      setRole(data.role)
    
    
    };


    fetching();
  }, [match.params.id]);

  const resetHandler = () => {
    setName("");
    setEmail("");
    setPassword("");
    setRole("");
  };

  const updateHandler = (e) => {
    e.preventDefault();
    dispatch(updateUserAction(match.params.id, name, email, password));
    if (!name|| !email|| !password) return;

    resetHandler();
    history.push("/MyCourses");
  };

  return (
            <div>
                <Form onSubmit={updateHandler}>

<Form.Group className="mb-3" controlId="formBasicEmail">
    <Form.Label className="L1">Name</Form.Label>
    <Form.Control type="text" placeholder="Enter Your Name"
    value={name}
    onChange={(e)=>setName(e.target.value)} />
  </Form.Group>


  <Form.Group className="mb-3" controlId="formBasicEmail">
    <Form.Label>Email address</Form.Label>
    <Form.Control type="email" placeholder="Enter email" 
    value={email}
    onChange={(e)=>setEmail(e.target.value)}/>
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicPassword">
    <Form.Label>Password</Form.Label>
    <Form.Control type="password" placeholder="Password" 
    value={password}
    onChange={(e)=>setPassword(e.target.value)}/>
  </Form.Group>

   <Form.Group className="mb-3" controlId="formBasicPassword">
    <Form.Label>Role</Form.Label>
    <Form.Control type="text" placeholder="Confirm Password" 
    value={role}
    onChange={(e)=>setRole(e.target.value)}/>
  </Form.Group> 

  
  

  <Button variant="primary" type="submit">
            Update User
          </Button>
          <Button
            className="mx-2"
            variant="danger"
            onClick={() => deleteHandler(match.params.id)}
          >
            Delete User
          </Button>


 






</Form>
            </div>

  );
}

export default SingleUSer
