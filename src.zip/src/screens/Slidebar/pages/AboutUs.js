import React from "react";

export const AboutUs = () => {
return (
	<div className="home">
	<h1>GeeksforGeeks About us</h1>
	</div>
);
};

// export const Mentor = () => {
// 	return (
// 		<div className="home">
// 		<h1>GeeksforGeeks About</h1>
// 		</div>
// 	);
// 	};

export const OurAim = () => {
return (
	<div className="home">
	<h1>GeeksforGeeks Aim</h1>
	</div>
);
};

export const OurVision = () => {
return (
	<div className="home">
	<h1>GeeksforGeeks Vision</h1>
	</div>
);
};

