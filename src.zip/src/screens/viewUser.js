import React, { useEffect } from "react";
import { Accordion, Badge, Button, Table } from "react-bootstrap";
import { Link } from "react-router-dom";

import { useDispatch, useSelector } from "react-redux";
import { deleteNoteAction, listNotes} from '../actions/noteActions'
import { deleteUserAction, listUsers  } from "../actions/userActions";


function MyNotes({ history, search }) 
{
  const dispatch = useDispatch();

//   const noteList = useSelector((state) => state.noteList);
//   const { loading, error, notes } = noteList;
  
  const userList = useSelector((state) => state.userList);
  const { loading, error,notes } = userList;


  // const filteredNotes = notes.filter((note) =>
  //   note.title.toLowerCase().includes(search.toLowerCase())
  //);

  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  const userDelete = useSelector((state) => state.userDelete);
  const {
    loading: loadingDelete,
    error: errorDelete,
    success: successDelete,
  } = userDelete;

  // const userCreate = useSelector((state) => state.userCreate);
  // const { success: successCreate } = userCreate;

  // const userRegister = useSelector((state) => state.userRegister);
  // const { loading, error, userInfo } = userRegister;

  // const userLogin = useSelector((state) => state.userLogin);
  // const { loading, error, userInfo } = userLogin;

  const userUpdate = useSelector((state) => state.userUpdate);
  const { success: successUpdate } = userUpdate;

  useEffect(() => {
    dispatch(listUsers());
    if (!userInfo) {
      history.push("/");
    }
  }, [

    dispatch,
    history,
    userInfo,
     successDelete,
    // successCreate,
      successUpdate,
  ]);

  const deleteHandler = (id) => {
    if (window.confirm("Are you sure?")) {
      dispatch(deleteUserAction(id));
    }
  };

  return (
    <div>

  
   
    
      {notes && 
        

          notes.map((note) => (

             <div>

            <Table striped bordered hover variant="dark">
            <thead>
              <tr>
  
                <th>User_Name</th>
                <th>Email</th>
          
                  <th>Role</th> 
                  
                <th>Action</th>

              </tr>
            </thead>
            <tbody>
              <tr key={note._id}>
            
                <td>{note.name}</td>
                <td>{note.email}</td>
          
                <td>{note.role}</td>

                  

                <td><Button href={`/courses/${note._id}`}>Edit</Button>  <Button
                                variant="danger"
                                className="mx-2"
                                onClick={() => deleteHandler(note._id)}
                              >
                                Delete
                              </Button></td>
                
              </tr>
              
              {/* <tr>
                <td>2</td>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <td>3</td>
                <td colSpan="2">Larry the Bird</td>
                <td>@twitter</td>
                <td><Button href={`/courses/${note._id}`}>Edit</Button>  <Button
                                variant="danger"
                                className="mx-2"
                                onClick={() => deleteHandler(note._id)}
                              >
                                Delete
                              </Button></td>
          
              </tr> */}
            </tbody>
          </Table>
          </div>
          ))
           }
   </div>
  );
}

export default MyNotes;
