import React, { useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, NavDropdown, Nav, Container, Button} from 'react-bootstrap';
import { Link, useHistory } from 'react-router-dom';
import Mynotes from '../screens/Mynotes'
import { useDispatch, useSelector } from 'react-redux'
import { logout } from '../actions/userActions';




function Header() {
const history = useHistory();
  const dispatch = useDispatch();

  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  const logoutHandler = () => {
    dispatch(logout());
    history.push('/')
  };

  useEffect(() => {}, [userInfo]);
    return (
    
        <div className="header1">
    <Navbar collapseOnSelect expand="lg">
  <Container>
  <Navbar.Brand href="/">
      <Link to='/'>
      <img src="https://github.com/mdo.png" alt="mdo" width="32" height="32" className="rounded-circle"></img>
      </Link></Navbar.Brand>
    

  

    {/* <Nav className="justify-content-right">
      <Nav.Link href="/Mynotes">
          <Link to= "/Mynotes">
          My notes
          </Link>
          </Nav.Link> */}

          {/* <Nav.Link href="#features"><Button variant="secondary">Login</Button>
</Nav.Link>
          
      <Nav.Link href="#features"><Button variant="secondary">Signup</Button> */}
{/* </Nav.Link> */}



<Nav>
            {/* {userInfo &&
              <>

      
              {userInfo.role==="user" &&
                <Link to="/Mynotes">My Notes</Link>}

              {userInfo.role==="mentor" &&
                <Link to="/MyCourses">My Course</Link>}

              {userInfo.role==="admin" &&
 
                <Link to="/Admin">Admin</Link>}
                
              {userInfo.role==="mentor" &&
 
              <Link to="/Mentor">Mentor</Link>} */}

{/*                 
{userInfo.role==="mentor" &&
 
 <Link to="/SingleNote">Edit My Course</Link>}
               {userInfo.role==="mentor" &&
 
               <Link to="/viewUser">View</Link>} */}

              {/* {userInfo.role==="mentor" &&
 
              <Link to="/MentorDashboard">Dashboard</Link>} */}

                <NavDropdown
                  title={`${userInfo.name}`}
                  id="collasible-nav-dropdown"
                >
                  <NavDropdown.Item href="/Mentor">
                    {/* <img
                      alt=""
                      src={`${userInfo.pic}`}
                      width="25"
                      height="25"
                      style={{ marginRight: 10 }}
                    /> */}
                    My Profile
                  </NavDropdown.Item>

                

                  

                  <NavDropdown.Divider />
                  <NavDropdown.Item onClick={logoutHandler}>
                    Logout
                  </NavDropdown.Item>
                </NavDropdown>
              
              
            
          </Nav>
  </Container>
  </Navbar>
        </div>
    )
}

export default Header
