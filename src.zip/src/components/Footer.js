import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, NavDropdown, Nav, Container, Button} from 'react-bootstrap';

export default function Footer() {
    return (
        <div style={{"background":"black"}}>

            <a>Hello</a>
            
        </div>
    )
}
