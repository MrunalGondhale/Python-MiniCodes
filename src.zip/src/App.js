import logo from "./logo.svg";
import "./App.css";
import Header from "./components/Header";
import Landing from "./screens/Landing";
import Footer from "./components/Footer";
import { BrowserRouter, Route } from "react-router-dom";
import ProtectedRoute from "./ProtectedRoute";
import Mynotes from "./screens/Mynotes";
import Login from "./screens/Login";
import Registration  from "./screens/Registration";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import PrivateRoute from './PrivateRoute';
import Mentor from './screens/Mentor';
import MyCourses from "./screens/MyCourses";
import viewUser from "./screens/viewUser";
import SingleNote from "./screens/SingleNote";
import SingleUSer from "./screens/SingleUSer";
import MentorDashboard from "./screens/MentorDashboard";






function App() {
  const [isAuth,setIsAuth]= useState("")

  const userLogin = useSelector((state) => state.userLogin);
  const {userInfo} = userLogin

  useEffect(() => {
    if (userInfo) {
       console.log(userInfo.role)
      setIsAuth(userInfo.role)

      
    }
  }, [ userInfo]);
  return (
    <div className="App">
      <BrowserRouter>
        <Header />

        <div className="main">
    

          

        
          
           <Route exact path='/' component={Landing}></Route>
           <Route  exact path='/login'  component={Login} ></Route>
           <Route exact path='/register' component={Registration}></Route>
           <Route exact path='/courses/:id' component={SingleNote}></Route>
           <Route exact path='/users/:id' component={SingleUSer}></Route>
           <Route  exact path='/MentorDashboard'  component={MentorDashboard} ></Route>






       <ProtectedRoute exact path ='/Mynotes' component={Mynotes} IsAuth={isAuth}></ProtectedRoute>
       <PrivateRoute exact path ='/Mentor' component={Mentor} IsAuth={isAuth}></PrivateRoute> 
       <PrivateRoute exact path ='/MyCourses' component={MyCourses} IsAuth={isAuth}></PrivateRoute>
       <PrivateRoute exact path ='/viewUser' component={viewUser} IsAuth={isAuth}></PrivateRoute>



       {/* <PrivateRoute exact path ='/MentorDashboard' component={MentorDashboard} IsAuth={isAuth}></PrivateRoute> */}



      
        </div>

        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
